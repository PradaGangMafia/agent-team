# AGENTS.md — Agent-Fleet build contract

This file is the operating system for the orchestrator and for every subagent.
It outranks defaults, habits, and any prompt text that contradicts it.

## 0. Shape of the work

`agent-fleet` is a Rust workspace: an encrypted, signed, store-and-forward task
queue for a fleet of agents behind untrusted relays. 74 prompts in `prompts/`,
one per session, in eleven phases. Code lives in `build/`. Docs stay at the root.

## 1. Roles

Two roles, and they never merge.

ORCHESTRATOR. Owns `todo.md`, owns commits, owns the gate. Issues exactly one
prompt file per subagent invocation. Never writes feature code.

SUBAGENT. One prompt, one fresh context, then stops. Sees `AGENTS.md`, the boot
sequence, and its own prompt file. Nothing else.

## 2. One prompt per invocation

A subagent does not chain. When its prompt is green and logged it stops, even
with context left. The orchestrator does not issue P(n+1) until P(n) is committed
and the gate is green.

## 3. Boot sequence, every session

1. `pwd` — must contain `AGENTS.md`, else stop.
2. `git status` — must be clean, else stop (§12).
3. `git log --oneline -5` — the tip must be the previous prompt's commit.
4. Read `todo.md`, `README.md`, `docs/VOCAB.md`, `docs/SPEC.md`.
5. Read the newest three `docs/journal/` files.
6. Read the prompt file in full.
7. Work.

## 4. Ledger is orchestrator-owned

Subagents never edit `todo.md`. The orchestrator flips `[~]` before dispatch and
`[x]` only after it has personally run the gate and seen it green. A crashed
subagent therefore cannot leave a stale claim, and a subagent cannot mark its own
homework.

`[ ]` pending, `[~]` dispatched, `[x]` verified. No other states. Never reorder,
never delete a line. A skip is `[x] P31 — hole punching (SKIPPED: reason)` plus a
journal entry.

## 5. Journal

One file per prompt, `docs/journal/p31.md`, written by the subagent before it
returns. Sections in order: Status, Commit, Duration, Intent, What changed,
Decisions, Acceptance, Open threads, For the next session. Append one line to
`docs/journal/INDEX.md`: `P31 DONE <sha> — <one-liner>`.

The sha is filled by the orchestrator if the subagent could not commit. `none` is
only legal for a prompt with no commit. A `DONE none` on a committed prompt is a
defect to fix.

## 6. Commits

One per prompt: `<phase>.<prompt>: <imperative summary>`. Body says why and points
at the journal. Never `--amend` a pushed commit, never `--force`, never
`--no-verify`. Never commit `target/`, `*.part`, `*.new`, `*.old`, state dirs,
`*.db`, secrets, or a `config.toml` holding real keys.

## 7. Gate

The orchestrator runs both, itself, after every prompt:

    cargo clippy --workspace --all-targets -- -D warnings
    cargo test --workspace

A subagent claiming green is not evidence. Zero warnings, zero failures, plus the
prompt's own suite green. At each phase's last prompt also run every accumulated
`t`, `m`, `n`, `p`, `d`, `s`, `r` test. A phase does not close over a red earlier
phase.

Also check every time:

- No `unwrap`/`expect` outside `#[cfg(test)]` and test modules.
- No `println!` outside `crates/adminctl`.
- No `rusqlite` in `agentd`, `transport`, `relayd`, `msgfmt`.
- Doc comment on every public item and every module.
- A `thiserror` enum per crate; no `anyhow` in libraries.
- `#![forbid(unsafe_code)]` at every crate root.

## 8. Unsafe policy

`forbid` is the default and must not be pre-emptively relaxed. A crate that needs
unsafe switches to `#![deny(unsafe_code)]` with `#[allow(unsafe_code)]` on the
specific module, records why in `docs/UNSAFE.md` with the file and the call, and
notes it in the journal. Unsafe is only for libc/Windows FFI with no safe
alternative. Every block carries a `// SAFETY:` comment naming the invariant.

## 9. Frozen wire format

`crates/msgfmt` is FROZEN after P06. You may add `MsgType` and `TaskBody` variants
with matching encode/decode pairs. You may not change header layout, padding,
signing range, AAD, verify order, or an existing public signature. P06 writes
`crates/msgfmt/FROZEN` holding the header byte table and the BLAKE3 of it; every
later prompt that touches msgfmt must show that file still matches.

## 10. Dependencies

One new dependency per prompt, the one the prompt names, pinned in
`[workspace.dependencies]`. A prompt needing a second is a conflict: say so and
stop.

## 11. Hard rules

1. Never invent an API. Not in the tree, not in the prompt: ask.
2. Prompt conflicts with the tree: quote both, stop.
3. A peer is untrusted exactly like a relay. Peer records verify against the
   enrolled set. Peers never assert task content.
4. Resilience invariants: never self-terminate on a hash mismatch; a failed
   mirror write never fails the operation; every repair is logged.
5. Match style: module doc, doc per public item, `thiserror` per crate, no
   synonyms outside `docs/VOCAB.md`.
6. Touch only files the prompt names. A file needed but unnamed is a conflict.

## 12. Dirty tree

Do not start on a dirty tree. Uncommitted work matching the previous prompt with a
`BLOCKED` journal: finish or revert it, log, commit, then continue. Unrelated
debris: stash and note it. Work from a live session: check the claim.

## 13. Failure

Three attempts per acceptance bullet, then stop, mark `BLOCKED` in the journal
naming the bullet, the error and the two approaches ruled out. The orchestrator
leaves the ledger `[~]` and does not advance.

## 14. Handoff

Final message ends with exactly this and nothing after it:

    ---
    PROMPT: P31 — hole punching
    STATUS: DONE
    FILES: <changed paths>
    TESTS: <n>/<n> pass, names
    GATE: clippy clean / test clean
    JOURNAL: docs/journal/p31.md
    ---

Then stop.

## 15. Phase table

| Phase | Prompts | Name |
|---|---|---|
| 0 | P01–P02 | SCAFFOLD |
| 1 | P03–P06 | WIRE FORMAT |
| 2 | P07–P14 | TRANSPORT |
| 3 | P15–P23 | MULTI-RELAY |
| 4 | P24–P25 | IDENTITY |
| 5 | P26–P32 | P2P |
| 6 | P33–P40 | PLUGINS |
| 7 | P41–P46 | FINDINGS |
| 8 | P47–P54 | PRODUCTION |
| 9 | P55–P62 | MOD TRUST |
| 10 | P63–P71 | RESILIENCE |
| 11 | P72–P74 | LAUNCH |

Each phase assumes the previous is load-bearing. Never reorder.

## 16. Voice

Chat: short, factual, no preamble, no emoji. Journal: past tense, specific, name
the bug you almost shipped. Never summarise a prompt back at the user.
