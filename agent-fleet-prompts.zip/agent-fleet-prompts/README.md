# Agent-Fleet Build Prompts

Extracted from BUILD GUIDE v2.

- `AGENTS.md` — the operating contract for orchestrator and subagents
- `prompts/p01.md` … `prompts/p74.md` — one prompt file per session

Issue exactly one prompt file per subagent invocation.

Phases:

| Phase | Prompts | Name |
|-------|---------|------|
| 0 | P01–P02 | SCAFFOLD |
| 1 | P03–P06 | WIRE FORMAT |
| 2 | P07–P14 | TRANSPORT |
| 3 | P15–P23 | MULTI-RELAY |
| 4 | P24–P25 | IDENTITY |
| 5 | P26–P32 | P2P |
| 6 | P33–P40 | PLUGINS |
| 7 | P41–P46 | FINDINGS |
| 8 | P47–P54 | PRODUCTION |
| 9 | P55–P62 | MOD TRUST |
| 10 | P63–P71 | RESILIENCE |
| 11 | P72–P74 | LAUNCH |
